export type MyString = string;
