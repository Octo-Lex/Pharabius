type MyEmptyArray = [];
