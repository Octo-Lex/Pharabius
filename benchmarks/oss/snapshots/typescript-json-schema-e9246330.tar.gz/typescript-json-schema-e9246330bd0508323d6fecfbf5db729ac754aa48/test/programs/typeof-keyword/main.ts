interface MyObject {
  foo: () => string;
}
