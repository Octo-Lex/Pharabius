type MyFixedSizeArray = [string, number];

