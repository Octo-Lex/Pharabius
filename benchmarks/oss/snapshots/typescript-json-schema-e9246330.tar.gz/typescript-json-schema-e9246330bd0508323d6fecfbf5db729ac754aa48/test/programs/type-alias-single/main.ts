type MyString = string;
