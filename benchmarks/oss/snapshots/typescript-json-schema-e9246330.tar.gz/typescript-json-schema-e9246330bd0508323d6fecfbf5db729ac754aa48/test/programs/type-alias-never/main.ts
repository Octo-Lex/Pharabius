export type MyNever = never;
