interface MyObject {
    myFunction: Function;
}