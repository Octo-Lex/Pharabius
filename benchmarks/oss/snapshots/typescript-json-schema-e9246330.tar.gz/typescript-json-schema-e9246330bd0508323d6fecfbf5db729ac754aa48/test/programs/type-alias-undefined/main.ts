export type MyUndefined = undefined;
